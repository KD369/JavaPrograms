package com.BridgeLabz.ds2;

public class Node<T> {
 
	Node head = null;
	Node next;
	T data;

	
	
}
